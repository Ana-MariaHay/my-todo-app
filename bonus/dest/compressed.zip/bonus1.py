title = input("enter the title: ")

print("the length of the title is", len(title))