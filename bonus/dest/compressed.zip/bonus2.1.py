password = input("Enter password: ")
while password != "pass123":
    print("You have entered the incorrect password")
    password = input("Enter password: ")

print("You have entered the correct password")